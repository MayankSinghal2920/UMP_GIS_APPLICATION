import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  standalone: true,
  template: `<p>Redirecting to application...</p>`,
})
export class HomeComponent implements OnInit {

  ngOnInit(): void {
    // ✅ Redirect to legacy GIS entry page
    window.location.href = 'index.html';
  }
}

