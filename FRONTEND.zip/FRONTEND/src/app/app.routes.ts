import { Routes } from '@angular/router';
import { Login } from './components/login/login';
import { HomeComponent } from './components/home/home';

export const routes: Routes = [

  // 👇 LOGIN opens FIRST
  { path: '', component: Login },

  // 👇 After login
  { path: 'home', component: HomeComponent },

  // fallback
  { path: '**', redirectTo: '' }
];
