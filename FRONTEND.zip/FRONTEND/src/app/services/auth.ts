import { Injectable } from '@angular/core';
import { tap, Observable } from 'rxjs';
import { Api } from './api';

@Injectable({
  providedIn: 'root',
})
export class Auth {

  constructor(private api: Api) {}

  /**
   * Login using backend API and
   * store user info in localStorage (legacy-compatible)
   */
  login(username: string, password: string): Observable<any> {
    return this.api.login(username, password).pipe(
      tap((res) => {

        // If backend sends token (optional)
        if (res?.token) {
          localStorage.setItem('token', res.token);
        }

        // Backend user object
        const u = res?.user || {};

        // ✅ Store exactly like your old JS login
        localStorage.setItem('user_id', u.user_id || '');
        localStorage.setItem('user_name', u.user_name || '');
        localStorage.setItem('railway', u.railway || '');
        localStorage.setItem('division', u.division || '');
        localStorage.setItem('department', u.department || '');

      })
    );
  }

  /**
   * Client-side logout only
   */
  logout(): void {
    localStorage.removeItem('token');
    localStorage.removeItem('user_id');
    localStorage.removeItem('user_name');
    localStorage.removeItem('railway');
    localStorage.removeItem('division');
    localStorage.removeItem('department');
  }

  isLoggedIn(): boolean {
    return !!localStorage.getItem('user_id');
  }

  getUserId(): string | null {
    return localStorage.getItem('user_id');
  }

  getUserName(): string | null {
    return localStorage.getItem('user_name');
  }

  getDivision(): string | null {
    return localStorage.getItem('division');
  }

  getRailway(): string | null {
    return localStorage.getItem('railway');
  }
}

