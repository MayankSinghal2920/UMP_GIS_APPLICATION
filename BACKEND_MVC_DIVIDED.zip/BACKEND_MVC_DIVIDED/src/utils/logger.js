module.exports = {
  info: (...a) => console.log(...a),
  error: (...a) => console.error(...a)
};
