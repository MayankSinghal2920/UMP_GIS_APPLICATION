module.exports = {
  SERVER_ERROR: "Server error",
};
